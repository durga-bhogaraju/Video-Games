"""World Cup match outcome prediction package."""
