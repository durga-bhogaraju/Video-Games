"""Load and clean the international results dataset."""
from __future__ import annotations

import os

import numpy as np
import pandas as pd

DATA_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data",
    "results.csv",
)


def match_importance(tournament: str) -> int:
    """Map a tournament name to a K-factor / importance weight.

    Higher means a more meaningful match (used by the Elo model and as an
    ML feature). Loosely follows the World Football Elo conventions.
    """
    t = tournament.lower()
    if "world cup" in t and "qual" not in t:
        return 60  # World Cup finals
    if "qual" in t:
        return 40  # Qualifiers
    if any(k in t for k in ("uefa euro", "copa", "africa cup", "asian cup",
                            "gold cup", "confederations", "nations league")):
        return 50  # Major continental finals
    if "friendly" in t:
        return 20
    return 30  # Other competitive matches


def load_results(path: str = DATA_PATH) -> pd.DataFrame:
    """Load results.csv into a cleaned, chronologically sorted DataFrame.

    Adds:
      - ``outcome``      : 'H' (home win), 'D' (draw), 'A' (away win)
      - ``importance``   : tournament weight (see :func:`match_importance`)
      - ``neutral``      : bool, whether the venue was neutral
    """
    df = pd.read_csv(path, parse_dates=["date"])
    df = df.dropna(subset=["home_score", "away_score"]).copy()
    df["home_score"] = df["home_score"].astype(int)
    df["away_score"] = df["away_score"].astype(int)

    # Normalise the neutral flag (stored as strings TRUE/FALSE in the source).
    df["neutral"] = df["neutral"].astype(str).str.upper().eq("TRUE")

    df["outcome"] = np.where(
        df["home_score"] > df["away_score"], "H",
        np.where(df["home_score"] < df["away_score"], "A", "D"),
    )
    df["importance"] = df["tournament"].apply(match_importance)

    df = df.sort_values("date").reset_index(drop=True)
    return df


def train_test_split_by_date(df: pd.DataFrame, cutoff: str):
    """Split chronologically: matches before ``cutoff`` train, on/after test.

    A time-based split (rather than random) is essential here so the model is
    never evaluated on information from its own future.
    """
    cutoff_ts = pd.Timestamp(cutoff)
    train = df[df["date"] < cutoff_ts].copy()
    test = df[df["date"] >= cutoff_ts].copy()
    return train, test


if __name__ == "__main__":
    d = load_results()
    print(f"{len(d):,} matches from {d['date'].min().date()} "
          f"to {d['date'].max().date()}")
    print(d["outcome"].value_counts(normalize=True).round(3).to_dict())
