"""Poisson goals model (a pure statistical baseline).

Each team gets an *attack* strength and a *defence* strength, estimated with a
single Poisson regression over goals scored. A match is predicted by computing
each side's expected goals, then summing the bivariate (independent) Poisson
score matrix into home-win / draw / away-win probabilities.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from scipy import sparse
from scipy.stats import poisson
from sklearn.linear_model import PoissonRegressor

# Recency weighting: matches older than the half-life count for less.
HALF_LIFE_DAYS = 365 * 6
MAX_GOALS = 10


class PoissonModel:
    LABELS = ["H", "D", "A"]

    def __init__(self, alpha: float = 1e-3) -> None:
        self.reg = PoissonRegressor(alpha=alpha, max_iter=500)
        self.team_index: dict[str, int] = {}

    # -- design matrix ---------------------------------------------------
    def _build_rows(self, teams, opps, home_flags):
        """Build a sparse design matrix: [attack(team) | defence(opp) | home]."""
        t = len(self.team_index)
        n = len(teams)
        rows, cols, vals = [], [], []
        for i in range(n):
            ti = self.team_index.get(teams[i])
            oi = self.team_index.get(opps[i])
            if ti is not None:
                rows.append(i); cols.append(ti); vals.append(1.0)
            if oi is not None:
                rows.append(i); cols.append(t + oi); vals.append(1.0)
            rows.append(i); cols.append(2 * t); vals.append(float(home_flags[i]))
        return sparse.csr_matrix((vals, (rows, cols)), shape=(n, 2 * t + 1))

    def fit(self, df: pd.DataFrame) -> "PoissonModel":
        teams = sorted(set(df["home_team"]) | set(df["away_team"]))
        self.team_index = {tm: i for i, tm in enumerate(teams)}

        # Long format: one row per (team, opponent, goals-scored) observation.
        scoring = np.concatenate([df["home_team"].to_numpy(),
                                  df["away_team"].to_numpy()])
        conceding = np.concatenate([df["away_team"].to_numpy(),
                                    df["home_team"].to_numpy()])
        # Home advantage only applies at non-neutral venues for the home side.
        home_flag = np.concatenate([
            np.where(df["neutral"].to_numpy(), 0.0, 1.0),
            np.zeros(len(df)),
        ])
        goals = np.concatenate([df["home_score"].to_numpy(),
                                df["away_score"].to_numpy()]).astype(float)

        max_date = df["date"].max()
        age_days = (max_date - df["date"]).dt.days.to_numpy()
        w = 0.5 ** (age_days / HALF_LIFE_DAYS)
        weight = np.concatenate([w, w])

        x = self._build_rows(scoring, conceding, home_flag)
        self.reg.fit(x, goals, sample_weight=weight)
        return self

    # -- prediction ------------------------------------------------------
    def expected_goals(self, home_team: str, away_team: str,
                       neutral: bool = True) -> tuple[float, float]:
        x = self._build_rows(
            [home_team, away_team],
            [away_team, home_team],
            [0.0 if neutral else 1.0, 0.0],
        )
        mu = self.reg.predict(x)
        return float(mu[0]), float(mu[1])

    def predict_match(self, home_team: str, away_team: str,
                      neutral: bool = True) -> dict[str, float]:
        mu_h, mu_a = self.expected_goals(home_team, away_team, neutral)
        ph = poisson.pmf(np.arange(MAX_GOALS + 1), mu_h)
        pa = poisson.pmf(np.arange(MAX_GOALS + 1), mu_a)
        matrix = np.outer(ph, pa)  # P(home=i, away=j)
        p_home = np.tril(matrix, -1).sum()   # i > j
        p_draw = np.trace(matrix)            # i == j
        p_away = np.triu(matrix, 1).sum()    # i < j
        total = p_home + p_draw + p_away
        return {"H": p_home / total, "D": p_draw / total, "A": p_away / total,
                "exp_home_goals": mu_h, "exp_away_goals": mu_a}

    def predict_proba(self, df: pd.DataFrame) -> np.ndarray:
        out = np.empty((len(df), 3))
        ht = df["home_team"].to_numpy()
        at = df["away_team"].to_numpy()
        nt = df["neutral"].to_numpy()
        for i in range(len(df)):
            p = self.predict_match(ht[i], at[i], bool(nt[i]))
            out[i] = [p["H"], p["D"], p["A"]]
        return out
