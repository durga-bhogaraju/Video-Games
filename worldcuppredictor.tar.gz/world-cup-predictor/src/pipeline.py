"""Shared helpers to load data and fit the three models."""
from __future__ import annotations

import os

import pandas as pd

from . import ml_model
from .data_prep import load_results
from .elo import EloModel, compute_elo
from .ml_model import MLModel
from .poisson import PoissonModel

DATA_PATH = os.path.join(
    os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
    "data", "results.csv",
)


def load_and_prepare(download_if_missing: bool = True):
    """Load results, compute Elo ratings over full history, return (df, ratings).

    The returned ``df`` is annotated with pre-match Elo columns. ``ratings`` is
    the final (current) Elo rating for every team.
    """
    if not os.path.exists(DATA_PATH) and download_if_missing:
        from data.download_data import download  # type: ignore
        download()
    df = load_results(DATA_PATH)
    ratings = compute_elo(df)  # annotates df in place
    return df, ratings


def fit_models(train: pd.DataFrame) -> dict:
    """Fit all three models on the given training slice."""
    elo = EloModel().fit(train)
    poisson = PoissonModel().fit(train)
    x_train = ml_model.build_features(train)
    ml = MLModel().fit(x_train, train["outcome"].to_numpy())
    return {"Elo": elo, "Poisson": poisson, "ML": ml}
