"""Scoring metrics for comparing models."""
from __future__ import annotations

import numpy as np

LABELS = ["H", "D", "A"]
_LABEL_IDX = {c: i for i, c in enumerate(LABELS)}


def _onehot(y: np.ndarray) -> np.ndarray:
    m = np.zeros((len(y), 3))
    for i, lab in enumerate(y):
        m[i, _LABEL_IDX[lab]] = 1.0
    return m


def accuracy(proba: np.ndarray, y: np.ndarray) -> float:
    pred = np.array(LABELS)[proba.argmax(axis=1)]
    return float((pred == y).mean())


def log_loss(proba: np.ndarray, y: np.ndarray) -> float:
    p = np.clip(proba, 1e-12, 1.0)
    truth = _onehot(y)
    return float(-(truth * np.log(p)).sum(axis=1).mean())


def brier(proba: np.ndarray, y: np.ndarray) -> float:
    """Multiclass Brier score (lower is better)."""
    truth = _onehot(y)
    return float(((proba - truth) ** 2).sum(axis=1).mean())


def score_all(proba: np.ndarray, y: np.ndarray) -> dict[str, float]:
    return {
        "accuracy": accuracy(proba, y),
        "log_loss": log_loss(proba, y),
        "brier": brier(proba, y),
    }
