"""Elo rating system for international football.

Two pieces:

1. :func:`compute_elo` walks the match history in order, maintaining a rating
   per team. It annotates each match with the teams' *pre-match* ratings so
   they can be used as leak-free features elsewhere.

2. :class:`EloModel` turns the pre-match rating difference into calibrated
   home-win / draw / away-win probabilities via a multinomial logistic fit.
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from sklearn.linear_model import LogisticRegression

BASE_RATING = 1500.0
HOME_ADVANTAGE = 65.0  # Elo points added to the home side at a non-neutral venue


def _goal_multiplier(goal_diff: int) -> float:
    """Scale the rating update by margin of victory (World Football Elo style)."""
    g = abs(goal_diff)
    if g <= 1:
        return 1.0
    if g == 2:
        return 1.5
    return (11 + g) / 8.0


def compute_elo(df: pd.DataFrame) -> dict[str, float]:
    """Compute Elo ratings over the full history, annotating ``df`` in place.

    Adds columns ``elo_home_pre``, ``elo_away_pre`` (ratings *before* the match)
    and ``elo_diff`` (home rating + home advantage - away rating).

    Returns the final rating for every team.
    """
    ratings: dict[str, float] = {}
    home_pre = np.empty(len(df))
    away_pre = np.empty(len(df))
    diff = np.empty(len(df))

    home_teams = df["home_team"].to_numpy()
    away_teams = df["away_team"].to_numpy()
    home_scores = df["home_score"].to_numpy()
    away_scores = df["away_score"].to_numpy()
    neutrals = df["neutral"].to_numpy()
    importances = df["importance"].to_numpy()

    for i in range(len(df)):
        h, a = home_teams[i], away_teams[i]
        rh = ratings.get(h, BASE_RATING)
        ra = ratings.get(a, BASE_RATING)
        home_pre[i] = rh
        away_pre[i] = ra

        ha = 0.0 if neutrals[i] else HOME_ADVANTAGE
        dr = (rh + ha) - ra
        diff[i] = dr

        # Expected score for the home team.
        exp_home = 1.0 / (1.0 + 10 ** (-dr / 400.0))

        hs, as_ = home_scores[i], away_scores[i]
        if hs > as_:
            actual = 1.0
        elif hs < as_:
            actual = 0.0
        else:
            actual = 0.5

        k = importances[i] * _goal_multiplier(hs - as_)
        delta = k * (actual - exp_home)
        ratings[h] = rh + delta
        ratings[a] = ra - delta

    df["elo_home_pre"] = home_pre
    df["elo_away_pre"] = away_pre
    df["elo_diff"] = diff
    return ratings


class EloModel:
    """Maps an Elo rating difference to W/D/L probabilities."""

    LABELS = ["H", "D", "A"]

    def __init__(self) -> None:
        self.clf = LogisticRegression(max_iter=1000, C=1.0)

    def fit(self, df: pd.DataFrame) -> "EloModel":
        x = df[["elo_diff"]].to_numpy()
        y = df["outcome"].to_numpy()
        self.clf.fit(x, y)
        # Remember class order so we can return columns consistently.
        self._classes = list(self.clf.classes_)
        return self

    def predict_proba(self, elo_diff: np.ndarray) -> np.ndarray:
        """Return an (n, 3) array of probabilities ordered [H, D, A]."""
        elo_diff = np.asarray(elo_diff, dtype=float).reshape(-1, 1)
        raw = self.clf.predict_proba(elo_diff)
        order = [self._classes.index(c) for c in self.LABELS]
        return raw[:, order]

    def predict_match(self, elo_home: float, elo_away: float,
                      neutral: bool = True) -> dict[str, float]:
        ha = 0.0 if neutral else HOME_ADVANTAGE
        dr = (elo_home + ha) - elo_away
        p = self.predict_proba(np.array([dr]))[0]
        return dict(zip(self.LABELS, p))
