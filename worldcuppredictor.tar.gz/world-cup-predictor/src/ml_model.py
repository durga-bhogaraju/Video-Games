"""Gradient-boosting classifier for match outcomes.

Builds leak-free features by walking the match history in order and keeping a
rolling window of each team's recent form, then trains a
HistGradientBoostingClassifier to predict home-win / draw / away-win.
"""
from __future__ import annotations

from collections import defaultdict, deque

import numpy as np
import pandas as pd
from sklearn.ensemble import HistGradientBoostingClassifier

FORM_WINDOW = 10  # number of recent matches used for rolling form
FEATURE_COLUMNS = [
    "elo_home_pre", "elo_away_pre", "elo_diff",
    "home_form", "away_form", "form_diff",
    "home_gf", "home_ga", "away_gf", "away_ga",
    "importance", "neutral",
]


def build_features(df: pd.DataFrame) -> pd.DataFrame:
    """Return a feature DataFrame aligned with ``df``.

    ``df`` must already carry the Elo pre-match columns
    (see :func:`elo.compute_elo`). Rolling features use only matches that
    occurred *before* each row, so there is no leakage.
    """
    history: dict[str, deque] = defaultdict(lambda: deque(maxlen=FORM_WINDOW))

    feats = {c: np.zeros(len(df)) for c in
             ["home_form", "away_form", "home_gf", "home_ga",
              "away_gf", "away_ga"]}

    ht = df["home_team"].to_numpy()
    at = df["away_team"].to_numpy()
    hs = df["home_score"].to_numpy()
    as_ = df["away_score"].to_numpy()

    def summarise(team):
        h = history[team]
        if not h:
            return 1.0, 1.0, 1.0  # neutral priors: 1 ppg, 1 goal for/against
        pts = np.mean([r[0] for r in h])
        gf = np.mean([r[1] for r in h])
        ga = np.mean([r[2] for r in h])
        return pts, gf, ga

    for i in range(len(df)):
        hp, hgf, hga = summarise(ht[i])
        ap, agf, aga = summarise(at[i])
        feats["home_form"][i] = hp
        feats["away_form"][i] = ap
        feats["home_gf"][i] = hgf
        feats["home_ga"][i] = hga
        feats["away_gf"][i] = agf
        feats["away_ga"][i] = aga

        # Record this match into both teams' history.
        if hs[i] > as_[i]:
            hp_pts, ap_pts = 3, 0
        elif hs[i] < as_[i]:
            hp_pts, ap_pts = 0, 3
        else:
            hp_pts, ap_pts = 1, 1
        history[ht[i]].append((hp_pts, hs[i], as_[i]))
        history[at[i]].append((ap_pts, as_[i], hs[i]))

    out = pd.DataFrame(feats, index=df.index)
    out["elo_home_pre"] = df["elo_home_pre"].to_numpy()
    out["elo_away_pre"] = df["elo_away_pre"].to_numpy()
    out["elo_diff"] = df["elo_diff"].to_numpy()
    out["form_diff"] = out["home_form"] - out["away_form"]
    out["importance"] = df["importance"].to_numpy()
    out["neutral"] = df["neutral"].astype(int).to_numpy()
    return out[FEATURE_COLUMNS]


def current_team_state(df: pd.DataFrame) -> dict[str, tuple]:
    """Return each team's latest rolling form as (points_pg, gf, ga).

    Used to build feature rows for *future* matches that are not in ``df``.
    """
    history: dict[str, deque] = defaultdict(lambda: deque(maxlen=FORM_WINDOW))
    ht = df["home_team"].to_numpy()
    at = df["away_team"].to_numpy()
    hs = df["home_score"].to_numpy()
    as_ = df["away_score"].to_numpy()
    for i in range(len(df)):
        if hs[i] > as_[i]:
            hp, ap = 3, 0
        elif hs[i] < as_[i]:
            hp, ap = 0, 3
        else:
            hp, ap = 1, 1
        history[ht[i]].append((hp, hs[i], as_[i]))
        history[at[i]].append((ap, as_[i], hs[i]))

    state = {}
    for team, h in history.items():
        if h:
            state[team] = (np.mean([r[0] for r in h]),
                           np.mean([r[1] for r in h]),
                           np.mean([r[2] for r in h]))
    return state


def feature_row(home_team, away_team, elo_home, elo_away, neutral,
                state, importance=60) -> pd.DataFrame:
    """Build a single-match feature row for the ML model."""
    from .elo import HOME_ADVANTAGE
    hp, hgf, hga = state.get(home_team, (1.0, 1.0, 1.0))
    ap, agf, aga = state.get(away_team, (1.0, 1.0, 1.0))
    ha = 0.0 if neutral else HOME_ADVANTAGE
    row = {
        "elo_home_pre": elo_home, "elo_away_pre": elo_away,
        "elo_diff": (elo_home + ha) - elo_away,
        "home_form": hp, "away_form": ap, "form_diff": hp - ap,
        "home_gf": hgf, "home_ga": hga, "away_gf": agf, "away_ga": aga,
        "importance": importance, "neutral": int(neutral),
    }
    return pd.DataFrame([row])[FEATURE_COLUMNS]


class MLModel:
    LABELS = ["H", "D", "A"]

    def __init__(self) -> None:
        self.clf = HistGradientBoostingClassifier(
            learning_rate=0.05,
            max_iter=400,
            max_depth=4,
            l2_regularization=1.0,
            random_state=42,
        )

    def fit(self, x: pd.DataFrame, y: np.ndarray) -> "MLModel":
        self.clf.fit(x, y)
        self._classes = list(self.clf.classes_)
        return self

    def predict_proba(self, x: pd.DataFrame) -> np.ndarray:
        raw = self.clf.predict_proba(x)
        order = [self._classes.index(c) for c in self.LABELS]
        return raw[:, order]
