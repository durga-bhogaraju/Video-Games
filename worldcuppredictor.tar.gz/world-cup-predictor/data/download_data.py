"""Download the international football results dataset.

Source: https://github.com/martj42/international_results
A community-maintained dataset of every international men's football match
since 1872 (~49k matches). Public domain (CC0).
"""
from __future__ import annotations

import os
import urllib.request

DATA_DIR = os.path.dirname(os.path.abspath(__file__))
RESULTS_URL = (
    "https://raw.githubusercontent.com/martj42/"
    "international_results/master/results.csv"
)
RESULTS_PATH = os.path.join(DATA_DIR, "results.csv")


def download(force: bool = False) -> str:
    """Download results.csv if it is not already present.

    Returns the local path to the dataset.
    """
    if os.path.exists(RESULTS_PATH) and not force:
        print(f"Dataset already present: {RESULTS_PATH}")
        return RESULTS_PATH

    print(f"Downloading match results from {RESULTS_URL} ...")
    urllib.request.urlretrieve(RESULTS_URL, RESULTS_PATH)
    size = os.path.getsize(RESULTS_PATH)
    print(f"Saved {RESULTS_PATH} ({size/1e6:.1f} MB)")
    return RESULTS_PATH


if __name__ == "__main__":
    download(force=True)
