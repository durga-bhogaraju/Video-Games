"""Train all three models on historical data and compare them on a held-out,
time-based test set (default: matches from 2018 onward, which includes the
2018 and 2022 World Cups).

Usage:
    python run.py [--cutoff YYYY-MM-DD]
"""
from __future__ import annotations

import argparse

import numpy as np

from src import evaluate, ml_model
from src.pipeline import fit_models, load_and_prepare
from src.data_prep import train_test_split_by_date


def _proba_for(name, model, test):
    if name == "Elo":
        return model.predict_proba(test["elo_diff"].to_numpy())
    if name == "Poisson":
        return model.predict_proba(test)
    if name == "ML":
        return model.predict_proba(ml_model.build_features(test))
    raise ValueError(name)


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--cutoff", default="2018-01-01",
                    help="train < cutoff, test >= cutoff (YYYY-MM-DD)")
    args = ap.parse_args()

    print("Loading data and computing Elo ratings ...")
    df, _ = load_and_prepare()
    train, test = train_test_split_by_date(df, args.cutoff)
    print(f"Train: {len(train):,} matches  |  Test: {len(test):,} matches "
          f"(from {args.cutoff})\n")

    print("Fitting models ...")
    models = fit_models(train)

    # Baseline: always predict the most common training outcome's prior.
    priors = train["outcome"].value_counts(normalize=True)
    base = np.tile([priors.get("H", 0), priors.get("D", 0),
                    priors.get("A", 0)], (len(test), 1))

    y = test["outcome"].to_numpy()
    wc_mask = test["tournament"].str.contains("World Cup", case=False) & \
        ~test["tournament"].str.contains("qual", case=False)

    rows = []
    proba_cache = {"Baseline (priors)": base}
    for name, model in models.items():
        proba_cache[name] = _proba_for(name, model, test)

    print("\n=== All international matches in test period ===")
    _print_table(proba_cache, y)

    print(f"\n=== World Cup finals matches only "
          f"({int(wc_mask.sum())} matches) ===")
    yw = y[wc_mask.to_numpy()]
    _print_table({k: v[wc_mask.to_numpy()] for k, v in proba_cache.items()}, yw)


def _print_table(proba_cache, y):
    header = f"{'Model':<20}{'Accuracy':>10}{'LogLoss':>10}{'Brier':>10}"
    print(header)
    print("-" * len(header))
    for name, proba in proba_cache.items():
        s = evaluate.score_all(proba, y)
        print(f"{name:<20}{s['accuracy']:>10.3f}"
              f"{s['log_loss']:>10.3f}{s['brier']:>10.3f}")


if __name__ == "__main__":
    main()
