# World Cup Match Predictor

Predicts the outcome (home win / draw / away win) of international football
matches, built and tuned for FIFA World Cup games. It trains **three different
models** on ~49,000 international matches since 1872 and compares them, then
lets you predict any matchup or a fixtures file.

## The three models

| Model | Type | How it works |
|-------|------|--------------|
| **Elo** | Statistical | Classic chess-style ratings adapted for football (margin-of-victory scaling, match-importance weighting, home advantage). A logistic layer converts the rating gap into W/D/L probabilities. |
| **Poisson** | Statistical | Each team gets an attack and defence strength via Poisson regression (recency-weighted). A match is scored by summing the bivariate Poisson goal matrix. Also gives an expected scoreline. |
| **ML** | Machine learning | `HistGradientBoostingClassifier` over engineered features: Elo ratings, rolling form, recent goals for/against, match importance, neutral venue. |

An **ensemble** (average of the three) is also reported for predictions.

## Setup

```bash
pip install -r requirements.txt
python data/download_data.py      # downloads the match dataset (~5 MB)
```

Data source: [martj42/international_results](https://github.com/martj42/international_results) (CC0).

## Usage

**Compare the models** on a time-based held-out test set (trains on matches
before the cutoff, tests on everything after — default 2018, which includes the
2018 & 2022 World Cups):

```bash
python run.py                     # default cutoff 2018-01-01
python run.py --cutoff 2022-01-01
```

**Predict a single match** (defaults to a neutral venue, as at a World Cup):

```bash
python predict.py "Argentina" "France"
python predict.py "Brazil" "Germany" --home    # first team plays at home
```

**Predict a fixtures file** (CSV with `home,away` columns — see
`fixtures_example.csv`):

```bash
python predict.py --fixtures fixtures_example.csv
```

## How good is it?

On all international matches from 2018 onward (~8k games), out-of-sample:

| Model | Accuracy | Log-loss | Brier |
|-------|---------:|---------:|------:|
| Baseline (class priors) | 0.478 | 1.051 | 0.634 |
| Elo | 0.600 | 0.874 | 0.514 |
| Poisson | 0.592 | 0.898 | 0.528 |
| ML | 0.600 | 0.872 | 0.513 |

All three clearly beat the naive baseline. On World Cup-finals matches alone
the Poisson model edges ahead on calibration. ~60% three-way accuracy is in
line with what published football models achieve — draws in particular are
inherently hard to call. (Re-run `python run.py` to reproduce; exact numbers
shift as the dataset updates.)

## Project layout

```
data/download_data.py   download the results dataset
src/data_prep.py        load, clean, label, time-based split
src/elo.py              Elo ratings + logistic W/D/L head
src/poisson.py          Poisson attack/defence goals model
src/ml_model.py         feature engineering + gradient boosting
src/evaluate.py         accuracy / log-loss / Brier metrics
src/pipeline.py         shared load + fit helpers
run.py                  train & compare all models
predict.py              predict a match or a fixtures file
```

## Notes & ideas to extend

- Predictions are **neutral-venue by default**; pass `--home` for host games.
- All evaluation uses a **chronological split** (never trains on the future),
  and rolling features are strictly leak-free.
- Possible extensions: Dixon–Coles low-score correction, player/squad data,
  bookmaker-odds calibration, and a Monte-Carlo tournament-bracket simulator.
```
