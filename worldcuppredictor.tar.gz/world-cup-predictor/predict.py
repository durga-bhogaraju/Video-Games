"""Predict the outcome of a single match or a fixtures file.

Models are fit on the full match history each run. Predictions default to a
neutral venue (as at a World Cup).

Examples:
    python predict.py "Argentina" "France"
    python predict.py "Brazil" "Germany" --home          # non-neutral venue
    python predict.py --fixtures fixtures.csv             # batch (home,away)
"""
from __future__ import annotations

import argparse

import numpy as np
import pandas as pd

from src import ml_model
from src.elo import BASE_RATING
from src.pipeline import fit_models, load_and_prepare

LABELS = ["H", "D", "A"]


def _predict_one(models, ratings, state, home, away, neutral):
    eh = ratings.get(home, BASE_RATING)
    ea = ratings.get(away, BASE_RATING)
    elo_p = models["Elo"].predict_match(eh, ea, neutral)
    poi_p = models["Poisson"].predict_match(home, away, neutral)
    row = ml_model.feature_row(home, away, eh, ea, neutral, state)
    ml_p = models["ML"].predict_proba(row)[0]
    ml_p = dict(zip(LABELS, ml_p))

    ensemble = {k: np.mean([elo_p[k], poi_p[k], ml_p[k]]) for k in LABELS}
    return {
        "Elo": elo_p,
        "Poisson": poi_p,
        "ML": ml_p,
        "Ensemble": ensemble,
        "exp_score": (poi_p["exp_home_goals"], poi_p["exp_away_goals"]),
    }


def _print_prediction(home, away, neutral, res):
    venue = "neutral venue" if neutral else f"{home} at home"
    print(f"\n{home}  vs  {away}   ({venue})")
    print(f"{'Model':<12}{home[:10]+' win':>16}{'Draw':>10}"
          f"{away[:10]+' win':>16}")
    print("-" * 54)
    for name in ["Elo", "Poisson", "ML", "Ensemble"]:
        p = res[name]
        print(f"{name:<12}{p['H']:>16.1%}{p['D']:>10.1%}{p['A']:>16.1%}")
    eh, ea = res["exp_score"]
    print(f"Poisson expected score: {home} {eh:.2f} - {ea:.2f} {away}")


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("home", nargs="?", help="home / first team")
    ap.add_argument("away", nargs="?", help="away / second team")
    ap.add_argument("--home", dest="home_adv", action="store_true",
                    help="treat as a non-neutral venue (first team at home)")
    ap.add_argument("--fixtures", help="CSV with columns home,away")
    args = ap.parse_args()

    print("Loading data and fitting models on full history ...")
    df, ratings = load_and_prepare()
    models = fit_models(df)
    state = ml_model.current_team_state(df)

    neutral = not args.home_adv

    if args.fixtures:
        fx = pd.read_csv(args.fixtures)
        for _, r in fx.iterrows():
            res = _predict_one(models, ratings, state,
                               r["home"], r["away"], neutral)
            _print_prediction(r["home"], r["away"], neutral, res)
        return

    if not args.home or not args.away:
        ap.error("provide two team names, or --fixtures FILE")

    for team in (args.home, args.away):
        if team not in ratings:
            print(f"  ! warning: '{team}' not found in data; "
                  f"using base rating. Check spelling.")

    res = _predict_one(models, ratings, state, args.home, args.away, neutral)
    _print_prediction(args.home, args.away, neutral, res)


if __name__ == "__main__":
    main()
